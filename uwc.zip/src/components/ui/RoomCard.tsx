// src/components/ui/RoomCard.tsx

"use client"

import Image from 'next/image';
import Link from 'next/link'; 
import { motion, type Variants } from 'framer-motion'; 
import HoverLink from '@/components/ui/HoverLink'; 

// KUNCI PERBAIKAN: INTERFACE SINKRON DENGAN JSON (id: number, tanpa price)
type RoomType = {
  id: number; // HARUS number
  name: string;
  subtitle: string; // HARUS subtitle
  // price: string; <-- DIHAPUS
  imageUrl: string;
  detailsHref: string; // HARUS detailsHref
};

// Varian Animasi untuk Fade In Slide Up
const cardVariants: Variants = { 
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: 'easeOut',
    },
  },
};

type RoomCardProps = {
  room: RoomType;
};

export default function RoomCard({ room }: RoomCardProps) {
  // Pastikan kamu menggunakan room.subtitle dan room.detailsHref di JSX di bawah ini
  return (
    <motion.div 
      className="flex-grow-0 flex-shrink-0 basis-[90%] sm:basis-1/2 lg:basis-[40%] pl-4"
      variants={cardVariants}
    >
      <Link href={room.detailsHref} className="group block h-full">
        <div className="flex flex-col h-full bg-background">
          
          {/* Gambar Kamar */}
          <div className="relative aspect-[4/5] w-full overflow-hidden">
            <Image
              src={room.imageUrl}
              alt={room.name}
              fill
              sizes="(max-width: 768px) 90vw, 40vw"
              className="object-cover transition-transform duration-500 group-hover:scale-105"
            />
          </div>

          {/* Konten Teks */}
          <div className="pt-6 pb-2 px-2">
            
            <h3 className="font-serif text-2xl text-foreground group-hover:text-primary transition-colors">
              {room.name}
            </h3>
            
            <p className="font-sans text-sm text-foreground/70 mt-1 mb-2 uppercase tracking-wider">
              {room.subtitle} {/* Menggunakan subtitle */}
            </p>
            
            {/* Tombol Discover */}
            <div className="mt-4">
                <HoverLink href={room.detailsHref}>
                    Discover
                </HoverLink>
            </div>

          </div>
        </div>
      </Link>
    </motion.div>
  );
}